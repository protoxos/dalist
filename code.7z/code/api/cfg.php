<?php
define('DB_NAME', 'DBNAME_AQUI');
define('DB_USER', 'DBUSER_POR_AQUI');
define('DB_PASS', 'PASS_AQUI');
